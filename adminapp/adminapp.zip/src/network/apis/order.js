import db from '../firebase/firebaseConfig';

export function getAllOrderNames() {
    return db.collection('Order')
             .onSnapshot((data) => {return data.doc()})
            //  .then(reponse => {
            //      return reponse.docs.map(doc => {
            //          console.log(doc.data());
            //          return doc.data();
            //      })
            //  })
            //  .catch(e => console.log(e));

            
            // real time effect change 
}

export function deleteOrderNames(id) {
    return db.collection('Order', ref => {ref.where ("id" , "==" , id)}).doc("3JPRRuVZjea4P8QI5ojO")
             .delete()
             .then(reponse => {
                 console.log(reponse);
             })
             .catch(e => console.log(e));
}