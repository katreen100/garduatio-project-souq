const ProductSectionPage = () => {
    return (
        <>
        <h1>Product Section</h1>
        </>
    )
}


export default ProductSectionPage;