const CustomerSectionPage = () => {
    return (
        <>
        <h1>Customer Section</h1>
        </>
    )
}

export default CustomerSectionPage;