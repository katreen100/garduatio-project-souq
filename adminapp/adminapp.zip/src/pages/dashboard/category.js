const CategorySectionPage = () => {
    return (
        <>
        <h1>Category Section</h1>
        </>
    )
}

export default CategorySectionPage;