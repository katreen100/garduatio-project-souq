import { getAllOrderNames } from '../../network/apis/order';
import { useState , useEffect } from 'react';
import * as React from 'react';
import { DataGrid } from '@material-ui/data-grid';
import Button from "@material-ui/core/Button";
import { deleteOrderNames } from '../../network/apis/order';

const OrderSectionPage = () => {


    const columns = [
        { field: 'customerName', headerName: 'Customer', width: 120 },
        { field: 'id', headerName: 'ID', width: 70 },
        { field: 'nameProduct', headerName: 'Product', width: 120 },
        {
            field: 'quantity',
            headerName: 'Quantity',
            type: 'number',
            width: 130,
        },
        {
            field: 'telephoneCustomer',
            headerName: 'Tel Customer',

            width: 150,
        },

        {
            field: 'to',
            headerName: 'To',

            width: 100,
        },
        {
            field: 'totalPrice',
            headerName: 'Price',
            type: 'number',
            width: 100,
        },
        {
            field: "",
            headerName: "Edit or Delete",
            sortable: false,
            width: 200,
            disableClickEventBubbling: true,
            renderCell: (params) => {
              const onClick = () => {
                const api = params.api;
                const fields = api
                  .getAllColumns()
                  .map((c) => c.field)
                  .filter((c) => c !== "__check__" && !!c);
                const thisRow = {};
        
                fields.forEach((f) => {
                  thisRow[f] = params.getValue(f);
                });
        
                return deleteOrderNames(2);
              };
        
              return <div>
                  <Button variant="contained" color="primary" onClick={ ()=> onClick(2) }>Edit</Button>
                  
                  </div>
              
            }
          },
          




    ];


    const initial = [{
        customerName: "",
        id: 0,
        nameProduct: "",
        quantity: 0,
        telephoneCustomer: "",
        to: "",
        totalPrice: 0
    }]

    const [all, setAll] = useState(initial);


    // console.log(getAllOrderNames()
    //     .then(res => { console.log(res.map(id => { console.log(id.id) })) }));
    useEffect(() => {
        getAllOrderNames().then(res => {
            // console.log(res);
            setAll(
    
                res.map(AllData => {
                    // console.log(AllData.id);
    
                    return AllData;
                })
            )
        })
        
    }, [])
    // getAllOrderNames().then(res => {
    //     // console.log(res);
    //     setAll(

    //         res.map(AllData => {
    //             // console.log(AllData.id);

    //             return AllData;
    //         })
    //     )
    // })
    return (
        <>
            <h1>Order Section</h1>
            <div>

                {/* <h1>{all[0].customerName}</h1>
                <h1>{all[0].id}</h1>

                <h1>{all[0].nameProduct}</h1>
                <h1>{all[0].quantity}</h1>
                <h1>{all[0].telephoneCustomer}</h1>
                <h1>{all[0].to}</h1>
                <h1>{all[0].totalPrice}</h1> */}



                {/* {getAllOrderNames().then(res => {
                    res.map(AllData => {
                        return <h1> {AllData} </h1>
                    })
                })} */}

                <div style={{ height: 400, width: '100%' }}>
                    <DataGrid rows={all} columns={columns} pageSize={5} checkboxSelection />
                </div>

            </div>

        </>
    )
}

export default OrderSectionPage;